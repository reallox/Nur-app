
let c=0;
function inc(){c++;document.getElementById('count').innerText=c;}
function reset(){c=0;document.getElementById('count').innerText=c;}
function show(id){
  ['quran','prayer','tasbih','athkar','qibla'].forEach(x=>{
    document.getElementById(x).classList.add('hidden');
  });
  document.getElementById(id).classList.remove('hidden');
}
